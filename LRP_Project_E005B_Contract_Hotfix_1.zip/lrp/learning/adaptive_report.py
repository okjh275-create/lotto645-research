"""Explainable adaptive-weight reporting for Project E E-005B."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
import math
from statistics import fmean
from typing import Any, Mapping, Sequence
from zoneinfo import ZoneInfo

from .adaptive_models import AdaptiveWeight


_KST = ZoneInfo("Asia/Seoul")
_VALID_DIRECTIONS = {"RAISED", "LOWERED", "UNCHANGED"}
_VALID_TRENDS = {"UP", "DOWN", "FLAT"}


def _required_text(value: object, *, field_name: str) -> str:
    if not isinstance(value, str):
        raise ValueError(f"{field_name} must be a string")
    normalized = value.strip()
    if not normalized:
        raise ValueError(f"{field_name} must not be empty")
    return normalized


def _finite_number(value: object, *, field_name: str) -> float:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ValueError(f"{field_name} must be numeric")
    normalized = float(value)
    if not math.isfinite(normalized):
        raise ValueError(f"{field_name} must be finite")
    return normalized


@dataclass(frozen=True, slots=True)
class AdaptiveWeightExplanation:
    """Human-readable explanation for one adaptive strategy weight."""

    strategy_type: str
    strategy_name: str
    rank_position: int
    previous_weight: float
    target_weight: float
    current_weight: float
    normalized_weight: float
    delta: float
    direction: str
    rank_score: float
    confidence: float
    stability: float
    trend: str
    sample_count: int
    reasons: tuple[str, ...] = field(default_factory=tuple)

    def __post_init__(self) -> None:
        strategy_type = _required_text(
            self.strategy_type,
            field_name="strategy_type",
        ).lower()
        strategy_name = _required_text(
            self.strategy_name,
            field_name="strategy_name",
        )
        if self.rank_position <= 0:
            raise ValueError("rank_position must be positive")
        if self.sample_count < 0:
            raise ValueError("sample_count must not be negative")

        direction = _required_text(
            self.direction,
            field_name="direction",
        ).upper()
        if direction not in _VALID_DIRECTIONS:
            raise ValueError(
                "direction must be RAISED, LOWERED, or UNCHANGED"
            )

        trend = _required_text(
            self.trend,
            field_name="trend",
        ).upper()
        if trend not in _VALID_TRENDS:
            raise ValueError("trend must be UP, DOWN, or FLAT")

        numeric_fields = {
            "previous_weight": self.previous_weight,
            "target_weight": self.target_weight,
            "current_weight": self.current_weight,
            "normalized_weight": self.normalized_weight,
            "delta": self.delta,
            "rank_score": self.rank_score,
            "confidence": self.confidence,
            "stability": self.stability,
        }
        normalized_values = {
            name: _finite_number(value, field_name=name)
            for name, value in numeric_fields.items()
        }

        non_negative = (
            "previous_weight",
            "target_weight",
            "current_weight",
            "normalized_weight",
            "rank_score",
            "confidence",
            "stability",
        )
        if any(normalized_values[name] < 0.0 for name in non_negative):
            raise ValueError("adaptive report values must be non-negative")

        reasons = tuple(
            _required_text(reason, field_name="reason")
            for reason in self.reasons
        )
        if not reasons:
            raise ValueError("reasons must not be empty")

        object.__setattr__(self, "strategy_type", strategy_type)
        object.__setattr__(self, "strategy_name", strategy_name)
        object.__setattr__(self, "direction", direction)
        object.__setattr__(self, "trend", trend)
        object.__setattr__(self, "reasons", reasons)

        for name, value in normalized_values.items():
            object.__setattr__(self, name, value)

    @property
    def key(self) -> tuple[str, str]:
        return self.strategy_type, self.strategy_name

    def as_dict(self) -> dict[str, Any]:
        return {
            "strategy_type": self.strategy_type,
            "strategy_name": self.strategy_name,
            "rank_position": self.rank_position,
            "previous_weight": round(self.previous_weight, 6),
            "target_weight": round(self.target_weight, 6),
            "current_weight": round(self.current_weight, 6),
            "normalized_weight": round(self.normalized_weight, 6),
            "delta": round(self.delta, 6),
            "direction": self.direction,
            "rank_score": round(self.rank_score, 6),
            "confidence": round(self.confidence, 6),
            "stability": round(self.stability, 6),
            "trend": self.trend,
            "sample_count": self.sample_count,
            "reasons": list(self.reasons),
        }


@dataclass(frozen=True, slots=True)
class AdaptiveWeightReport:
    """Immutable E-005B adaptive-weight report."""

    revision: tuple[int, int]
    strategy_type: str | None
    history_limit: int
    generated_at_kst: str
    summaries: tuple[AdaptiveWeightExplanation, ...]
    metadata: Mapping[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        revision = tuple(self.revision)
        if (
            len(revision) != 2
            or any(
                isinstance(value, bool)
                or not isinstance(value, int)
                or value < 0
                for value in revision
            )
        ):
            raise ValueError(
                "revision must contain two non-negative integers"
            )

        strategy_type = self.strategy_type
        if strategy_type is not None:
            strategy_type = _required_text(
                strategy_type,
                field_name="strategy_type",
            ).lower()

        if self.history_limit <= 0:
            raise ValueError("history_limit must be positive")

        generated_at_kst = _required_text(
            self.generated_at_kst,
            field_name="generated_at_kst",
        )

        summaries = tuple(self.summaries)
        if not all(
            isinstance(item, AdaptiveWeightExplanation)
            for item in summaries
        ):
            raise ValueError("summaries contains invalid items")

        keys = [item.key for item in summaries]
        if len(keys) != len(set(keys)):
            raise ValueError("summaries contains duplicate strategies")

        expected_order = tuple(
            sorted(
                summaries,
                key=lambda item: (
                    item.rank_position,
                    item.strategy_type,
                    item.strategy_name,
                ),
            )
        )
        if summaries != expected_order:
            raise ValueError("summaries must be ordered by rank position")

        if strategy_type is not None and any(
            item.strategy_type != strategy_type
            for item in summaries
        ):
            raise ValueError(
                "summary strategy_type does not match report filter"
            )

        if not isinstance(self.metadata, Mapping):
            raise ValueError("metadata must be a mapping")

        object.__setattr__(self, "revision", revision)
        object.__setattr__(self, "strategy_type", strategy_type)
        object.__setattr__(self, "generated_at_kst", generated_at_kst)
        object.__setattr__(self, "summaries", summaries)
        object.__setattr__(self, "metadata", dict(self.metadata))

    @property
    def strategy_count(self) -> int:
        return len(self.summaries)

    @property
    def raised_count(self) -> int:
        return sum(
            item.direction == "RAISED"
            for item in self.summaries
        )

    @property
    def lowered_count(self) -> int:
        return sum(
            item.direction == "LOWERED"
            for item in self.summaries
        )

    @property
    def unchanged_count(self) -> int:
        return sum(
            item.direction == "UNCHANGED"
            for item in self.summaries
        )

    @property
    def normalized_total(self) -> float:
        return round(
            sum(
                item.normalized_weight
                for item in self.summaries
            ),
            6,
        )

    @property
    def average_current_weight(self) -> float:
        if not self.summaries:
            return 0.0
        return float(
            fmean(item.current_weight for item in self.summaries)
        )

    @property
    def average_confidence(self) -> float:
        if not self.summaries:
            return 0.0
        return float(
            fmean(item.confidence for item in self.summaries)
        )

    @property
    def average_stability(self) -> float:
        if not self.summaries:
            return 0.0
        return float(
            fmean(item.stability for item in self.summaries)
        )

    @property
    def highest(self) -> AdaptiveWeightExplanation | None:
        if not self.summaries:
            return None
        return max(
            self.summaries,
            key=lambda item: (
                item.current_weight,
                -item.rank_position,
                item.strategy_type,
                item.strategy_name,
            ),
        )

    @property
    def lowest(self) -> AdaptiveWeightExplanation | None:
        if not self.summaries:
            return None
        return min(
            self.summaries,
            key=lambda item: (
                item.current_weight,
                item.rank_position,
                item.strategy_type,
                item.strategy_name,
            ),
        )

    def get(
        self,
        strategy_type: str,
        strategy_name: str,
    ) -> AdaptiveWeightExplanation | None:
        key = (
            _required_text(
                strategy_type,
                field_name="strategy_type",
            ).lower(),
            _required_text(
                strategy_name,
                field_name="strategy_name",
            ),
        )
        return next(
            (item for item in self.summaries if item.key == key),
            None,
        )

    def as_dict(self) -> dict[str, Any]:
        highest = self.highest
        lowest = self.lowest
        return {
            "revision": list(self.revision),
            "strategy_type": self.strategy_type,
            "history_limit": self.history_limit,
            "generated_at_kst": self.generated_at_kst,
            "strategy_count": self.strategy_count,
            "raised_count": self.raised_count,
            "lowered_count": self.lowered_count,
            "unchanged_count": self.unchanged_count,
            "normalized_total": self.normalized_total,
            "average_current_weight": round(
                self.average_current_weight,
                6,
            ),
            "average_confidence": round(
                self.average_confidence,
                6,
            ),
            "average_stability": round(
                self.average_stability,
                6,
            ),
            "highest": None if highest is None else highest.as_dict(),
            "lowest": None if lowest is None else lowest.as_dict(),
            "summaries": [item.as_dict() for item in self.summaries],
            "metadata": dict(self.metadata),
        }


class AdaptiveWeightReporter:
    """Convert calculated adaptive weights into an explainable report."""

    def __init__(
        self,
        *,
        unchanged_tolerance: float = 1e-9,
        high_confidence_threshold: float = 0.75,
        high_stability_threshold: float = 0.75,
    ) -> None:
        if unchanged_tolerance < 0.0:
            raise ValueError(
                "unchanged_tolerance must be non-negative"
            )
        for name, value in (
            (
                "high_confidence_threshold",
                high_confidence_threshold,
            ),
            (
                "high_stability_threshold",
                high_stability_threshold,
            ),
        ):
            if not 0.0 <= value <= 1.0:
                raise ValueError(f"{name} must be between 0 and 1")

        self.unchanged_tolerance = float(unchanged_tolerance)
        self.high_confidence_threshold = float(
            high_confidence_threshold
        )
        self.high_stability_threshold = float(
            high_stability_threshold
        )

    def build(
        self,
        weights: Sequence[AdaptiveWeight],
        *,
        strategy_type: str | None = None,
        history_limit: int = 100,
        generated_at_kst: str | None = None,
    ) -> AdaptiveWeightReport:
        if history_limit <= 0:
            raise ValueError("history_limit must be positive")

        normalized_type = (
            None
            if strategy_type is None
            else _required_text(
                strategy_type,
                field_name="strategy_type",
            ).lower()
        )

        items = tuple(weights)
        if not all(isinstance(item, AdaptiveWeight) for item in items):
            raise TypeError("weights must contain AdaptiveWeight items")

        if normalized_type is not None and any(
            item.strategy_type.lower() != normalized_type
            for item in items
        ):
            raise ValueError(
                "weight strategy_type does not match report filter"
            )

        revisions = {tuple(item.revision) for item in items}
        if len(revisions) > 1:
            raise ValueError("weights contain mixed revisions")
        revision = next(iter(revisions), (0, 0))

        timestamp = generated_at_kst
        if timestamp is None:
            timestamp = datetime.now(_KST).isoformat(
                timespec="seconds"
            )
        else:
            timestamp = _required_text(
                timestamp,
                field_name="generated_at_kst",
            )

        summaries = tuple(
            sorted(
                (self._explain(item) for item in items),
                key=lambda item: (
                    item.rank_position,
                    item.strategy_type,
                    item.strategy_name,
                ),
            )
        )

        if summaries:
            normalized_total = round(
                sum(
                    item.normalized_weight
                    for item in summaries
                ),
                6,
            )
            if abs(normalized_total - 1.0) > 1e-6:
                raise ValueError(
                    "normalized weights must sum to 1.0"
                )

        return AdaptiveWeightReport(
            revision=revision,
            strategy_type=normalized_type,
            history_limit=history_limit,
            generated_at_kst=timestamp,
            summaries=summaries,
            metadata={
                "source": "lrp.learning",
                "reporter": "E-005B",
                "read_only": True,
                "unchanged_tolerance": self.unchanged_tolerance,
                "high_confidence_threshold": (
                    self.high_confidence_threshold
                ),
                "high_stability_threshold": (
                    self.high_stability_threshold
                ),
            },
        )

    def _explain(
        self,
        weight: AdaptiveWeight,
    ) -> AdaptiveWeightExplanation:
        delta = round(
            weight.current_weight - weight.previous_weight,
            6,
        )
        if abs(delta) <= self.unchanged_tolerance:
            direction = "UNCHANGED"
        elif delta > 0.0:
            direction = "RAISED"
        else:
            direction = "LOWERED"

        reasons: list[str] = []

        if weight.rank_position == 1:
            reasons.append("최상위 전략 순위")
        elif weight.rank_position <= 3:
            reasons.append("상위권 전략 순위")
        else:
            reasons.append("전략 순위 반영")

        if weight.trend == "UP":
            reasons.append("최근 성과 추세 상승")
        elif weight.trend == "DOWN":
            reasons.append("최근 성과 추세 하락")
        else:
            reasons.append("최근 성과 추세 보합")

        if weight.confidence >= self.high_confidence_threshold:
            reasons.append("충분한 표본에 따른 높은 신뢰도")
        else:
            reasons.append("표본 신뢰도 제한 반영")

        if weight.stability >= self.high_stability_threshold:
            reasons.append("성과 변동성이 낮아 안정성 양호")
        else:
            reasons.append("성과 변동성에 따른 안정성 조정")

        if direction == "RAISED":
            reasons.append("목표 가중치 방향으로 현재 가중치 상승")
        elif direction == "LOWERED":
            reasons.append("목표 가중치 방향으로 현재 가중치 하락")
        else:
            reasons.append("이전 가중치와 실질적으로 동일")

        return AdaptiveWeightExplanation(
            strategy_type=weight.strategy_type,
            strategy_name=weight.strategy_name,
            rank_position=weight.rank_position,
            previous_weight=weight.previous_weight,
            target_weight=weight.target_weight,
            current_weight=weight.current_weight,
            normalized_weight=weight.normalized_weight,
            delta=delta,
            direction=direction,
            rank_score=weight.rank_score,
            confidence=weight.confidence,
            stability=weight.stability,
            trend=weight.trend,
            sample_count=weight.sample_count,
            reasons=tuple(reasons),
        )
